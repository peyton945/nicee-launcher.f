Nice UI 10 launcher v3: HUD layouts, music bar, clock styles, icon colours, HTML widgets.

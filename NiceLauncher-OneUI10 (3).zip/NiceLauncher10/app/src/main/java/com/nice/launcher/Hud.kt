@file:OptIn(ExperimentalFoundationApi::class)

package com.nice.launcher

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.sin

/** Chamfered-corner "tech" panel shape. */
val TechShape = GenericShape { size, _ ->
    val c = 22f
    moveTo(c, 0f)
    lineTo(size.width - c, 0f)
    lineTo(size.width, c)
    lineTo(size.width, size.height - c)
    lineTo(size.width - c, size.height)
    lineTo(c, size.height)
    lineTo(0f, size.height - c)
    lineTo(0f, c)
    close()
}

class SysStats(val ram: Float, val storage: Float)

fun readStats(ctx: Context): SysStats {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    val ram = if (mi.totalMem > 0) 1f - mi.availMem.toFloat() / mi.totalMem.toFloat() else 0f
    val fs = StatFs(Environment.getDataDirectory().path)
    val total = fs.totalBytes.toFloat()
    val free = fs.availableBytes.toFloat()
    return SysStats(ram, if (total > 0f) 1f - free / total else 0f)
}

@Composable
fun rememberStats(): SysStats {
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(SysStats(0.5f, 0.5f)) }
    LaunchedEffect(Unit) {
        while (true) {
            s = withContext(Dispatchers.Default) { readStats(ctx) }
            delay(5000)
        }
    }
    return s
}

@Composable
fun HudPage(
    st: LauncherSettings, ui: Ui, apps: List<AppItem>, battery: Int,
    onAi: () -> Unit, onDrawer: () -> Unit, onOpen: (String) -> Unit
) {
    val hs = ui.homeStyle
    val inf = rememberInfiniteTransition(label = "hud")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(40000, easing = LinearEasing)), label = "s1")
    val spin2 by inf.animateFloat(360f, 0f, infiniteRepeatable(tween(22000, easing = LinearEasing)), label = "s2")
    val sweepA by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "s3")
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    val stats = rememberStats()
    val dockApps = st.dock.mapNotNull { p -> apps.find { it.pkg == p } }
    val homeApps = st.home.mapNotNull { p -> apps.find { it.pkg == p } }.take(14)
    val inner = homeApps.take(6)
    val outer = homeApps.drop(6)
    val mono = FontFamily.Monospace

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = maxWidth
        val h = maxHeight
        val R = minOf(w, h * 0.6f) / 2f * 0.9f
        val cx = w / 2
        val cy = h * 0.44f
        val iconD = 42.dp

        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(cx.toPx(), cy.toPx())
            val r = R.toPx()
            val c1 = hs.c1
            drawCircle(Brush.radialGradient(listOf(c1.copy(0.28f), Color.Transparent), center = c, radius = r * 1.15f), radius = r * 1.15f, center = c)
            drawCircle(c1.copy(0.9f), radius = r, center = c, style = Stroke(3f))
            drawCircle(c1.copy(0.35f), radius = r * 0.97f, center = c, style = Stroke(1.5f))
            for (i in 0 until hs.ticks) {
                val a = Math.toRadians(i * 360.0 / hs.ticks - 90.0)
                val long = i % 5 == 0
                val r1 = r * (if (long) 0.86f else 0.9f)
                val r2 = r * 0.95f
                drawLine(
                    c1.copy(if (long) 0.95f else 0.5f),
                    Offset(c.x + (r1 * cos(a)).toFloat(), c.y + (r1 * sin(a)).toFloat()),
                    Offset(c.x + (r2 * cos(a)).toFloat(), c.y + (r2 * sin(a)).toFloat()),
                    strokeWidth = if (long) 3f else 1.5f
                )
            }
            val sa = Math.toRadians(now.second * 6.0 - 90.0)
            drawCircle(Color.White, radius = 7f, center = Offset(c.x + (r * 0.905f * cos(sa)).toFloat(), c.y + (r * 0.905f * sin(sa)).toFloat()))
            if (hs.sweep) {
                rotate(sweepA, pivot = c) {
                    drawCircle(Brush.sweepGradient(listOf(Color.Transparent, c1.copy(0.45f)), center = c), radius = r * 0.88f, center = c)
                }
            }
            rotate(spin, pivot = c) {
                drawCircle(c1.copy(0.55f), radius = r * 0.7f, center = c, style = Stroke(2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 14f))))
            }
            rotate(spin2, pivot = c) {
                val tl = Offset(c.x - r * 0.5f, c.y - r * 0.5f)
                val sz = Size(r, r)
                drawArc(hs.c2.copy(0.85f), 0f, 70f, false, topLeft = tl, size = sz, style = Stroke(4f, cap = StrokeCap.Round))
                drawArc(hs.c2.copy(0.85f), 180f, 70f, false, topLeft = tl, size = sz, style = Stroke(4f, cap = StrokeCap.Round))
            }
            drawCircle(c1.copy(0.22f), radius = r * 0.3f, center = c)
            drawCircle(c1, radius = r * 0.3f, center = c, style = Stroke(2f))
            rotate(spin, pivot = c) {
                drawArc(Color.White.copy(0.9f), 30f, 90f, false, topLeft = Offset(c.x - r * 0.36f, c.y - r * 0.36f), size = Size(r * 0.72f, r * 0.72f), style = Stroke(3f, cap = StrokeCap.Round))
            }
            fun gauge(startA: Float, sweep: Float, pct: Float, col: Color) {
                val rr = r * 1.04f
                val tl = Offset(c.x - rr, c.y - rr)
                val sz = Size(rr * 2, rr * 2)
                drawArc(col.copy(0.25f), startA, sweep, false, topLeft = tl, size = sz, style = Stroke(10f, cap = StrokeCap.Round))
                drawArc(col, startA, sweep * pct.coerceIn(0f, 1f), false, topLeft = tl, size = sz, style = Stroke(10f, cap = StrokeCap.Round))
            }
            gauge(190f, 58f, stats.ram, c1)
            gauge(252f, 36f, battery / 100f, hs.c2)
            gauge(292f, 58f, stats.storage, c1)
        }

        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = 18.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("RAM ${(stats.ram * 100).toInt()}%", color = hs.c1, fontFamily = mono, fontSize = 10.sp)
            Text("BAT $battery%", color = hs.c2, fontFamily = mono, fontSize = 10.sp)
            Text("STORAGE ${(stats.storage * 100).toInt()}%", color = hs.c1, fontFamily = mono, fontSize = 10.sp)
        }

        listOf(Triple(inner, 0.52f, -90.0), Triple(outer, 0.78f, -67.5)).forEach { (list, f, start) ->
            list.forEachIndexed { i, app ->
                val a = Math.toRadians(start + i * 360.0 / list.size)
                val x = cx + (R * f) * cos(a).toFloat() - iconD / 2
                val y = cy + (R * f) * sin(a).toFloat() - iconD / 2
                Box(
                    Modifier.offset(x, y).size(iconD).clip(CircleShape)
                        .background(Color.Black.copy(0.55f))
                        .border(1.5.dp, hs.c1.copy(0.8f), CircleShape)
                        .pressScale({ onOpen(app.pkg) })
                        .padding(5.dp)
                ) {
                    Image(app.icon, app.label, Modifier.fillMaxSize().clip(ui.shape.shape), colorFilter = ui.filterFor(app.pkg, hs.c2))
                }
            }
        }
        if (homeApps.isEmpty()) {
            Text(
                "Open the drawer, long-press apps and choose “Add to home” to fill the rings.",
                color = Color.White.copy(0.6f), fontFamily = mono, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.TopCenter).offset(y = cy + R * 0.45f).padding(horizontal = 40.dp)
            )
        }

        Column(
            Modifier.offset(cx - R * 0.3f, cy - R * 0.3f).size(R * 0.6f).clip(CircleShape).clickable { onAi() },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = mono)
            Text(now.format(DateTimeFormatter.ofPattern("EEE d MMM")).uppercase(), fontSize = 10.sp, color = hs.c2, fontFamily = mono)
            Text("✦ TAP FOR AI", fontSize = 9.sp, color = hs.c1, fontFamily = mono)
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 14.dp).padding(bottom = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "⌃ APPS", color = hs.c1, fontFamily = mono, fontSize = 11.sp,
                modifier = Modifier.clip(TechShape).clickable { onDrawer() }.padding(horizontal = 14.dp, vertical = 4.dp)
            )
            Spacer(Modifier.height(4.dp))
            Row(
                Modifier.fillMaxWidth().clip(TechShape).background(Color.Black.copy(0.6f))
                    .border(1.dp, hs.c1.copy(0.7f), TechShape)
                    .padding(vertical = 10.dp).heightIn(min = 44.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (dockApps.isEmpty()) {
                    Text("Pin apps to the dock from the drawer", color = Color.White.copy(0.6f), fontFamily = mono, fontSize = 11.sp)
                }
                dockApps.forEach { a ->
                    Image(
                        a.icon, a.label,
                        Modifier.size(44.dp).clip(CircleShape).border(1.dp, hs.c1.copy(0.6f), CircleShape).pressScale({ onOpen(a.pkg) }),
                        colorFilter = ui.filterFor(a.pkg, hs.c2)
                    )
                }
            }
        }
    }
}

@file:OptIn(ExperimentalFoundationApi::class)

package com.nice.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class Ui(
    val look: Look, val accent: Color, val accent2: Color, val glass: Float,
    val shape: IconShape, val iconSize: Dp, val labels: Boolean,
    val homeStyle: HomeStyle, val clock: ClockStyle, val tint: IconTint, val tintColor: Color
) {
    /** Colour filter for an app icon according to the chosen icon colour mode. */
    fun filterFor(pkg: String, auto: Color? = null): ColorFilter? {
        val c: Color = when (tint) {
            IconTint.ORIGINAL -> return null
            IconTint.AUTO -> auto ?: return null
            IconTint.MONO -> Color.White
            IconTint.ACCENT -> accent
            IconTint.RAINBOW -> Accents[abs(pkg.hashCode()) % Accents.size]
            IconTint.CUSTOM -> tintColor
        }
        val k = if (tint == IconTint.MONO) 1f else 1.3f
        return ColorFilter.colorMatrix(
            ColorMatrix(
                floatArrayOf(
                    0.299f * c.red * k, 0.587f * c.red * k, 0.114f * c.red * k, 0f, 0f,
                    0.299f * c.green * k, 0.587f * c.green * k, 0.114f * c.green * k, 0f, 0f,
                    0.299f * c.blue * k, 0.587f * c.blue * k, 0.114f * c.blue * k, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
}

val LocalUi = compositionLocalOf<Ui> { error("Ui not provided") }

fun Modifier.card(ui: Ui, radius: Dp = ui.look.radius.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    val fill = ui.look.card.copy(alpha = if (ui.look.glassy) ui.glass else ui.look.card.alpha)
    val base = if (ui.look.glow) this.shadow(12.dp, shape, ambientColor = ui.accent, spotColor = ui.accent) else this
    return base.clip(shape).background(fill).border(1.dp, ui.look.stroke(ui.accent), shape)
}

/** Bouncy press animation + haptic long-press. */
fun Modifier.pressScale(onClick: () -> Unit, onLong: (() -> Unit)? = null): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.86f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "press"
    )
    val hap = LocalHapticFeedback.current
    this.scale(s).combinedClickable(
        interactionSource = src, indication = null, onClick = onClick,
        onLongClick = onLong?.let { l -> { hap.performHapticFeedback(HapticFeedbackType.LongPress); l() } }
    )
}

@Composable
fun AppIcon(app: AppItem, ui: Ui, modifier: Modifier = Modifier, auto: Color? = null) {
    Image(
        app.icon, app.label, modifier.size(ui.iconSize).clip(ui.shape.shape),
        colorFilter = ui.filterFor(app.pkg, auto)
    )
}

@Composable
fun AppTile(app: AppItem, ui: Ui, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
    Column(Modifier.pressScale(onClick, onLong).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AppIcon(app, ui)
        if (ui.labels) {
            Spacer(Modifier.height(4.dp))
            Text(app.label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun Backdrop(ui: Ui) {
    val t by rememberInfiniteTransition(label = "bg").animateFloat(
        0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "t"
    )
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(ui.look.top, ui.look.bottom)))
        val b = ui.look.blob
        if (b > 0f) {
            val w = size.width
            val h = size.height
            val c1 = Offset(w * (0.15f + 0.7f * t), h * (0.2f + 0.1f * t))
            val c2 = Offset(w * (0.85f - 0.7f * t), h * (0.75f - 0.1f * t))
            drawCircle(Brush.radialGradient(listOf(ui.accent.copy(b), Color.Transparent), center = c1, radius = w), radius = w, center = c1)
            drawCircle(Brush.radialGradient(listOf(ui.accent2.copy(b * 0.8f), Color.Transparent), center = c2, radius = w), radius = w, center = c2)
        }
    }
}

@Composable
fun rememberBattery(): Int {
    val ctx = LocalContext.current
    var level by remember { mutableIntStateOf(100) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (l >= 0 && s > 0) level = l * 100 / s
            }
        }
        val sticky = ctx.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) r.onReceive(ctx, sticky)
        onDispose { ctx.unregisterReceiver(r) }
    }
    return level
}

/** Four animated equaliser bars. */
@Composable
fun EqBars(color: Color, playing: Boolean) {
    val t = rememberInfiniteTransition(label = "eq")
    val durations = listOf(420, 560, 380, 500)
    Row(Modifier.height(16.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        durations.forEach { d ->
            val h by t.animateFloat(
                0.25f, 1f, infiniteRepeatable(tween(d, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bar"
            )
            Box(Modifier.width(3.dp).fillMaxHeight(if (playing) h else 0.3f).clip(RoundedCornerShape(2.dp)).background(color))
        }
    }
}

/** Dynamic-island style pill. Shows the now-playing song with animated bars, or the battery. Tap to expand. */
@Composable
fun Island(ui: Ui, battery: Int, media: MediaInfo?, onAi: () -> Unit, onCmd: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.animateContentSize(spring(dampingRatio = 0.55f, stiffness = 300f))
            .clip(shape).background(Color.Black)
            .border(1.dp, ui.look.stroke(ui.accent), shape)
            .clickable { open = !open }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (media != null) {
            EqBars(ui.accent, media.playing)
            Spacer(Modifier.width(8.dp))
            Text(
                media.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = if (open) 150.dp else 120.dp)
            )
        } else {
            Text("✦", color = ui.accent)
            Spacer(Modifier.width(8.dp))
            Text("$battery%", color = Color.White, fontSize = 13.sp)
        }
        if (open) {
            if (media != null) {
                Spacer(Modifier.width(8.dp))
                Text("⏮", color = Color.White, modifier = Modifier.clickable { onCmd("prev") }.padding(horizontal = 6.dp))
                Text(if (media.playing) "⏸" else "▶", color = Color.White, modifier = Modifier.clickable { onCmd("toggle") }.padding(horizontal = 6.dp))
                Text("⏭", color = Color.White, modifier = Modifier.clickable { onCmd("next") }.padding(horizontal = 6.dp))
                Spacer(Modifier.width(6.dp))
                Text("$battery%", color = Color.White.copy(0.7f), fontSize = 12.sp)
            } else {
                Spacer(Modifier.width(14.dp))
                Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE d MMM")), color = Color.White.copy(0.8f), fontSize = 13.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text("Ask AI", color = ui.accent, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.clickable { open = false; onAi() })
        }
    }
}

fun wordsTime(t: LocalDateTime): String {
    val h = arrayOf("twelve", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven")
    val hour = t.hour % 12
    val next = h[(hour + 1) % 12]
    val m = t.minute
    val s = when {
        m < 3 -> "${h[hour]} o’clock"
        m < 8 -> "five past ${h[hour]}"
        m < 13 -> "ten past ${h[hour]}"
        m < 18 -> "quarter past ${h[hour]}"
        m < 23 -> "twenty past ${h[hour]}"
        m < 28 -> "twenty-five past ${h[hour]}"
        m < 33 -> "half past ${h[hour]}"
        m < 38 -> "twenty-five to $next"
        m < 43 -> "twenty to $next"
        m < 48 -> "quarter to $next"
        m < 53 -> "ten to $next"
        m < 58 -> "five to $next"
        else -> "$next o’clock"
    }
    return s.replaceFirstChar { it.uppercase() }
}

@Composable
fun AnalogClock(now: LocalDateTime, ui: Ui, dia: Dp) {
    val fg = LocalContentColor.current
    val acc = ui.accent
    Canvas(Modifier.size(dia)) {
        val r = size.minDimension / 2f
        val c = center
        drawCircle(fg.copy(0.35f), radius = r - 2f, center = c, style = Stroke(3f))
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0 - 90.0)
            val r1 = r * 0.84f
            val r2 = r * 0.94f
            drawLine(fg.copy(0.8f), Offset(c.x + (r1 * cos(a)).toFloat(), c.y + (r1 * sin(a)).toFloat()),
                Offset(c.x + (r2 * cos(a)).toFloat(), c.y + (r2 * sin(a)).toFloat()), strokeWidth = 4f, cap = StrokeCap.Round)
        }
        fun hand(deg: Float, len: Float, w: Float, col: Color) {
            val a = Math.toRadians(deg - 90.0)
            drawLine(col, c, Offset(c.x + (len * cos(a)).toFloat(), c.y + (len * sin(a)).toFloat()), strokeWidth = w, cap = StrokeCap.Round)
        }
        hand((now.hour % 12 + now.minute / 60f) * 30f, r * 0.5f, 9f, fg)
        hand((now.minute + now.second / 60f) * 6f, r * 0.75f, 6f, fg)
        hand(now.second * 6f, r * 0.85f, 3f, acc)
        drawCircle(acc, radius = 8f, center = c)
    }
}

@Composable
fun SecondsRing(now: LocalDateTime, ui: Ui, dia: Dp) {
    val fg = LocalContentColor.current
    val acc = ui.accent
    Canvas(Modifier.size(dia)) {
        val pad = 8f
        val tl = Offset(pad, pad)
        val sz = Size(size.width - pad * 2, size.height - pad * 2)
        drawArc(fg.copy(0.15f), 0f, 360f, false, topLeft = tl, size = sz, style = Stroke(10f))
        drawArc(acc, -90f, now.second / 60f * 360f, false, topLeft = tl, size = sz, style = Stroke(10f, cap = StrokeCap.Round))
    }
}

@Composable
fun ClockBlock(ui: Ui) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    val term = ui.look == Look.TERMINAL
    val centered = ui.look.centered
    val align = if (centered) Alignment.CenterHorizontally else Alignment.Start
    val glowCol = if (ui.look.glow) ui.accent else Color.Unspecified
    Column(Modifier.fillMaxWidth(), horizontalAlignment = align) {
        when (ui.clock) {
            ClockStyle.DIGITAL -> Text(
                now.format(DateTimeFormatter.ofPattern(if (term) "HH:mm:ss" else "HH:mm")),
                fontSize = if (term) 60.sp else 88.sp,
                fontWeight = if (ui.look == Look.CLASSIC) FontWeight.Light else FontWeight.Thin,
                color = glowCol
            )
            ClockStyle.STACKED -> {
                Text(now.format(DateTimeFormatter.ofPattern("HH")), fontSize = 92.sp, fontWeight = FontWeight.Bold, lineHeight = 84.sp, color = glowCol)
                Text(now.format(DateTimeFormatter.ofPattern("mm")), fontSize = 92.sp, fontWeight = FontWeight.Thin, lineHeight = 84.sp, color = ui.accent)
            }
            ClockStyle.ANALOG -> AnalogClock(now, ui, 160.dp)
            ClockStyle.RING -> Box(contentAlignment = Alignment.Center) {
                SecondsRing(now, ui, 180.dp)
                Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), fontSize = 44.sp, fontWeight = FontWeight.Thin)
            }
            ClockStyle.WORDS -> Text(
                wordsTime(now), fontSize = 34.sp, fontWeight = FontWeight.Light, lineHeight = 40.sp,
                textAlign = if (centered) TextAlign.Center else TextAlign.Start
            )
        }
        Text(
            now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
            fontSize = 18.sp, color = LocalContentColor.current.copy(0.8f)
        )
    }
}

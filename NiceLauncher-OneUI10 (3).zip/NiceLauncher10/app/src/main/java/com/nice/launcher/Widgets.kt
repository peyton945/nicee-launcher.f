package com.nice.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

const val EXAMPLE_CLOCK = """<div style="height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center">
<div id="t" style="font-size:44px;font-weight:200;color:var(--accent);text-shadow:0 0 18px var(--accent)"></div>
<div id="d" style="opacity:.7;font-size:13px"></div></div>
<script>
function u(){var n=new Date();
document.getElementById('t').textContent=n.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'});
document.getElementById('d').textContent=n.toDateString()}
u();setInterval(u,1000)
</script>"""

const val EXAMPLE_PULSE = """<style>
.b{display:flex;gap:6px;align-items:flex-end;height:60px;justify-content:center}
.b i{width:10px;background:var(--accent);border-radius:5px;animation:p 1s infinite ease-in-out alternate}
.b i:nth-child(2){animation-delay:.2s}.b i:nth-child(3){animation-delay:.4s}.b i:nth-child(4){animation-delay:.6s}
@keyframes p{from{height:10px}to{height:60px}}
button{margin-top:10px;background:var(--accent);color:#fff;border:0;border-radius:20px;padding:8px 18px}
</style>
<div style="text-align:center;padding-top:10px">
<div class="b"><i></i><i></i><i></i><i></i></div>
<button onclick="Nice.openApp('Camera')">Open Camera</button></div>"""

fun hexOf(c: Color): String = String.format("#%06X", 0xFFFFFF and c.toArgb())

fun wrapHtml(body: String, ui: Ui): String =
    "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>" +
        ":root{--accent:${hexOf(ui.accent)};--accent2:${hexOf(ui.accent2)};--text:${hexOf(ui.look.text)}}" +
        "html,body{margin:0;padding:0;height:100%;background:transparent;color:var(--text);font-family:sans-serif}" +
        "</style></head><body>" + body + "</body></html>"

/** Functions a widget's JavaScript can call as Nice.xxx() */
class WidgetBridge(private val ctx: Context, private val apps: () -> List<AppItem>, private val level: () -> Int) {
    @JavascriptInterface
    fun battery(): Int = level()

    @JavascriptInterface
    fun openApp(name: String) {
        findApp(apps(), name)?.let { launchPkg(ctx, it.pkg) }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HtmlWidget(w: Widget, ui: Ui, apps: List<AppItem>, battery: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val page = remember(w.html, ui.accent, ui.accent2, ui.look) { wrapHtml(w.html, ui) }
    val batteryNow = rememberUpdatedState(battery)
    val appsNow = rememberUpdatedState(apps)
    AndroidView(
        modifier = modifier.fillMaxWidth().height(w.height.dp).clip(RoundedCornerShape(ui.look.radius.dp)),
        factory = { c ->
            WebView(c).apply {
                setBackgroundColor(0)
                settings.javaScriptEnabled = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                isVerticalScrollBarEnabled = false
                addJavascriptInterface(WidgetBridge(ctx, { appsNow.value }, { batteryNow.value }), "Nice")
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, request?.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e: Exception) { }
                        return true
                    }
                }
                tag = page
                loadDataWithBaseURL(null, page, "text/html", "utf-8", null)
            }
        },
        update = { v ->
            if (v.tag != page) {
                v.tag = page
                v.loadDataWithBaseURL(null, page, "text/html", "utf-8", null)
            }
        }
    )
}

@Composable
fun WidgetEditor(initial: Widget?, onSave: (Widget) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "My widget") }
    var html by remember { mutableStateOf(initial?.html ?: EXAMPLE_CLOCK) }
    var height by remember { mutableStateOf((initial?.height ?: 140).toString()) }
    var onHome by remember { mutableStateOf(initial?.onHome ?: false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New widget" else "Edit widget") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    html, { html = it }, label = { Text("HTML / CSS / JS") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp),
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    height, { height = it.filter(Char::isDigit).take(3) }, label = { Text("Height (dp)") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                ToggleRow("Show on home screen", onHome) { onHome = it }
                Row {
                    TextButton(onClick = { html = EXAMPLE_CLOCK }) { Text("Clock example") }
                    TextButton(onClick = { html = EXAMPLE_PULSE }) { Text("Pulse example") }
                }
                Text(
                    "Tips: use var(--accent) and var(--text) for theme colours. In JavaScript, Nice.openApp('Spotify') opens an app and Nice.battery() returns the battery level.",
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(Widget(initial?.id ?: System.currentTimeMillis().toString(), name.ifBlank { "Widget" }, html, (height.toIntOrNull() ?: 140).coerceIn(60, 400), onHome))
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

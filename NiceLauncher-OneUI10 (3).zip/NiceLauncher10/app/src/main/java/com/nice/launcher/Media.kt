package com.nice.launcher

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Empty on purpose: having it enabled in "Notification access" lets the launcher read the now-playing session. */
class MediaListener : NotificationListenerService()

data class MediaInfo(val title: String, val artist: String, val playing: Boolean)

private fun controllerOf(ctx: Context): MediaController? = try {
    val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    val all = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
    all.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: all.firstOrNull()
} catch (e: Exception) {
    null
}

fun readMedia(ctx: Context): MediaInfo? {
    val c = controllerOf(ctx) ?: return null
    val title = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
    val artist = c.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
    return MediaInfo(title, artist, c.playbackState?.state == PlaybackState.STATE_PLAYING)
}

fun mediaCmd(ctx: Context, cmd: String) {
    val c = controllerOf(ctx) ?: return
    val t = c.transportControls
    when (cmd) {
        "prev" -> t.skipToPrevious()
        "next" -> t.skipToNext()
        else -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
    }
}

fun hasNotificationAccess(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: ""
    return s.contains(ctx.packageName)
}

@Composable
fun rememberMedia(): MediaInfo? {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf<MediaInfo?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            info = withContext(Dispatchers.Default) { readMedia(ctx) }
            delay(1500)
        }
    }
    return info
}

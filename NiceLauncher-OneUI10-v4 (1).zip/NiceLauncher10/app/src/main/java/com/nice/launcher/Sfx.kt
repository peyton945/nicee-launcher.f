package com.nice.launcher

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class Sound(val label: String) {
    TAP("Tap"), LONG("Hold"), OPEN("Open"), CLOSE("Close"), TOGGLE("Switch"),
    TICK("Tick"), LAUNCH("Launch"), SUCCESS("Success"), ERROR("Error"), MEDIA("Music")
}

/**
 * Sound effects. Every sound is synthesised in code the first time the launcher starts
 * (small WAV files in the cache folder), so no audio assets are needed.
 */
object Sfx {
    var enabled = true
    var volume = 0.7f

    private const val RATE = 22050
    private var pool: SoundPool? = null
    private val ids = ConcurrentHashMap<Sound, Int>()
    private val ready: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private var lastTick = 0L

    fun init(ctx: Context) {
        if (pool != null) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { _, id, status -> if (status == 0) ready.add(id) }
        pool = p
        Thread {
            for (s in Sound.values()) {
                try {
                    val f = File(ctx.cacheDir, "sfx_" + s.name.lowercase() + "_v1.wav")
                    if (!f.exists()) writeWav(f, pcm(synth(s)))
                    ids[s] = p.load(f.absolutePath, 1)
                } catch (e: Exception) { /* sound just stays silent */ }
            }
        }.start()
    }

    fun play(s: Sound) {
        if (!enabled || volume <= 0.01f) return
        if (s == Sound.TICK) {
            val now = System.currentTimeMillis()
            if (now - lastTick < 60) return
            lastTick = now
        }
        val id = ids[s] ?: return
        if (!ready.contains(id)) return
        pool?.play(id, volume, volume, 1, 0, 1f)
    }

    // ------------------------------------------------------------ synthesis
    private fun blip(f0: Double, f1: Double, ms: Int, gain: Double = 0.5, decay: Double = 6.0): DoubleArray {
        val n = RATE * ms / 1000
        val out = DoubleArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val p = i.toDouble() / n
            val f = f0 + (f1 - f0) * p
            ph += 2.0 * PI * f / RATE
            val attack = minOf(1.0, i / (RATE * 0.004))
            val tail = minOf(1.0, (n - i) / (RATE * 0.006))
            val env = attack * tail * exp(-decay * p)
            out[i] = (sin(ph) + 0.28 * sin(2 * ph) + 0.1 * sin(3 * ph)) * env * gain
        }
        return out
    }

    private fun cat(vararg parts: DoubleArray): DoubleArray {
        val out = DoubleArray(parts.sumOf { it.size })
        var o = 0
        for (p in parts) { p.copyInto(out, o); o += p.size }
        return out
    }

    private fun pcm(d: DoubleArray): ShortArray =
        ShortArray(d.size) { (d[it].coerceIn(-1.0, 1.0) * 32000).toInt().toShort() }

    private fun synth(s: Sound): DoubleArray = when (s) {
        Sound.TAP -> blip(900.0, 700.0, 45, 0.5, 7.0)
        Sound.LONG -> blip(300.0, 520.0, 120, 0.55, 3.0)
        Sound.OPEN -> blip(420.0, 920.0, 150, 0.5, 3.0)
        Sound.CLOSE -> blip(820.0, 380.0, 140, 0.5, 3.0)
        Sound.TOGGLE -> cat(blip(620.0, 620.0, 30, 0.45, 5.0), blip(930.0, 930.0, 45, 0.45, 6.0))
        Sound.TICK -> blip(1500.0, 1500.0, 18, 0.35, 8.0)
        Sound.LAUNCH -> blip(500.0, 1250.0, 190, 0.5, 2.5)
        Sound.SUCCESS -> cat(blip(660.0, 660.0, 70, 0.45, 4.0), blip(880.0, 880.0, 70, 0.45, 4.0), blip(1320.0, 1320.0, 140, 0.45, 5.0))
        Sound.ERROR -> cat(blip(320.0, 260.0, 90, 0.55, 3.0), blip(240.0, 190.0, 150, 0.55, 4.0))
        Sound.MEDIA -> blip(1000.0, 1300.0, 60, 0.45, 6.0)
    }

    private fun writeWav(f: File, pcm: ShortArray) {
        val bytes = pcm.size * 2
        val data = ByteBuffer.allocate(bytes).order(ByteOrder.LITTLE_ENDIAN)
        for (v in pcm) data.putShort(v)
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + bytes); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1.toShort()); h.putShort(1.toShort())
        h.putInt(RATE); h.putInt(RATE * 2); h.putShort(2.toShort()); h.putShort(16.toShort())
        h.put("data".toByteArray()); h.putInt(bytes)
        FileOutputStream(f).use { it.write(h.array()); it.write(data.array()) }
    }
}

@file:OptIn(ExperimentalFoundationApi::class)

package com.nice.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

fun expandPanel(ctx: Context) {
    try {
        val sb = ctx.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
    } catch (e: Exception) { /* not available on this device */ }
}

fun greeting(): String {
    val h = LocalDateTime.now().hour
    return when { h < 5 -> "Late night"; h < 12 -> "Good morning"; h < 18 -> "Good afternoon"; else -> "Good evening" }
}

fun initial(s: String): Char = s.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#'

// ---------------------------------------------------------------- HOME
@Composable
fun HomeScreen(
    st: LauncherSettings, ui: Ui, apps: List<AppItem>,
    onDrawer: () -> Unit, onSettings: () -> Unit, onAi: () -> Unit, onEdge: () -> Unit,
    onOpen: (String) -> Unit
) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = 1) { 2 }
    val battery = rememberBattery()
    val media = rememberMedia()
    val hud = ui.homeStyle.hud
    val curPage = pager.currentPage
    var lastPage by remember { mutableIntStateOf(curPage) }
    LaunchedEffect(curPage) { if (curPage != lastPage) { Sfx.play(Sound.TICK); lastPage = curPage } }
    val dockApps = st.dock.mapNotNull { p -> apps.find { it.pkg == p } }

    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -100f) onDrawer() else if (total > 100f) expandPanel(ctx) },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onSettings() }) }
    ) {
        if (hud) Box(Modifier.fillMaxSize().background(Color.Black.copy(0.78f)))
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
                Island(
                    ui, battery, media, onAi,
                    onSeek = { ms -> mediaSeek(ctx, ms) },
                    onOpenPlayer = { media?.let { m -> launchPkg(ctx, m.pkg) } }
                ) { cmd -> mediaCmd(ctx, cmd) }
            }
            HorizontalPager(pager, Modifier.weight(1f)) { page ->
                when {
                    page == 0 -> NowPage(st, ui, apps, battery, onOpen)
                    hud -> HudPage(st, ui, apps, battery, onAi, onDrawer, onOpen)
                    else -> HomePage(st, ui, apps, battery, onOpen)
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
                repeat(2) { i ->
                    Box(
                        Modifier.padding(3.dp).size(if (pager.currentPage == i) 18.dp else 7.dp, 7.dp)
                            .clip(CircleShape)
                            .background(if (pager.currentPage == i) ui.accent else LocalContentColor.current.copy(0.3f))
                    )
                }
            }
            if (!hud) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp).card(ui).clickable { onAi() }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("✦", fontSize = 20.sp, color = ui.accent)
                    Spacer(Modifier.width(12.dp))
                    Text("Ask AI to do something…", color = LocalContentColor.current.copy(0.7f))
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp).card(ui, (ui.look.radius + 6).dp)
                        .padding(vertical = 12.dp).heightIn(min = ui.iconSize),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (dockApps.isEmpty()) {
                        Text("Long-press an app in the drawer → Pin to dock", fontSize = 13.sp, color = LocalContentColor.current.copy(0.6f))
                    }
                    dockApps.forEach { a -> AppIcon(a, ui, Modifier.pressScale({ onOpen(a.pkg) })) }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        // right-edge panel handle
        Box(
            Modifier.align(Alignment.CenterEnd).fillMaxHeight(0.4f).width(22.dp)
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total < -40f) onEdge() },
                        onDragCancel = { total = 0f },
                        onHorizontalDrag = { _, dx -> total += dx }
                    )
                },
            contentAlignment = Alignment.CenterEnd
        ) {
            Box(Modifier.padding(end = 3.dp).size(4.dp, 70.dp).clip(CircleShape).background(ui.accent.copy(0.6f)))
        }
    }
}

@Composable
fun HomePage(st: LauncherSettings, ui: Ui, apps: List<AppItem>, battery: Int, onOpen: (String) -> Unit) {
    val homeApps = st.home.mapNotNull { p -> apps.find { it.pkg == p } }
    val homeWidgets = st.widgets.filter { it.onHome }
    LazyVerticalGrid(
        GridCells.Fixed(st.homeCols.coerceIn(3, 5)),
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 8.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                ClockBlock(ui)
                Spacer(Modifier.height(16.dp))
            }
        }
        items(homeWidgets, key = { it.id }, span = { GridItemSpan(maxLineSpan) }) { w ->
            Column {
                HtmlWidget(w, ui, apps, battery)
                Spacer(Modifier.height(10.dp))
            }
        }
        if (homeApps.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    "Your home is empty. Open the drawer (swipe up), long-press an app and choose “Add to home”.",
                    fontSize = 14.sp, color = LocalContentColor.current.copy(0.6f)
                )
            }
        } else {
            items(homeApps, key = { it.pkg }) { app ->
                var menu by remember { mutableStateOf(false) }
                Box(contentAlignment = Alignment.Center) {
                    AppTile(app, ui, { onOpen(app.pkg) }, { menu = true })
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(text = { Text("Remove from home") }, onClick = {
                            Sfx.play(Sound.TAP); menu = false; st.home = st.home - app.pkg; st.save()
                        })
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- NOW PAGE
@Composable
fun NowPage(st: LauncherSettings, ui: Ui, apps: List<AppItem>, battery: Int, onOpen: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(greeting(), fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            CalendarCard(ui, Modifier.weight(1.5f))
            BatteryCard(ui, battery, Modifier.weight(1f))
        }
        NotesCard(st, ui)
        st.widgets.forEach { w -> HtmlWidget(w, ui, apps, battery) }
        val recents = st.recents.mapNotNull { p -> apps.find { it.pkg == p } }
        Column(Modifier.fillMaxWidth().card(ui).padding(14.dp)) {
            Text("Recent", fontSize = 12.sp, color = ui.accent, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            if (recents.isEmpty()) {
                Text("Apps you open will show up here.", fontSize = 13.sp, color = LocalContentColor.current.copy(0.5f))
            } else {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    recents.forEach { a -> AppIcon(a, ui, Modifier.pressScale({ onOpen(a.pkg) })) }
                }
            }
        }
    }
}

@Composable
fun CalendarCard(ui: Ui, modifier: Modifier) {
    val today = LocalDate.now()
    val ym = YearMonth.from(today)
    val lead = ym.atDay(1).dayOfWeek.value % 7
    val days = ym.lengthOfMonth()
    val rows = (lead + days + 6) / 7
    Column(modifier.card(ui).padding(12.dp)) {
        Text(ym.format(DateTimeFormatter.ofPattern("MMMM yyyy")), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Spacer(Modifier.height(6.dp))
        Row {
            "SMTWTFS".forEach {
                Text(it.toString(), Modifier.weight(1f), fontSize = 10.sp, textAlign = TextAlign.Center,
                    color = LocalContentColor.current.copy(0.6f))
            }
        }
        for (r in 0 until rows) {
            Row {
                for (c in 0..6) {
                    val d = r * 7 + c - lead + 1
                    val isToday = d == today.dayOfMonth
                    Box(Modifier.weight(1f).height(24.dp), contentAlignment = Alignment.Center) {
                        if (d in 1..days) {
                            if (isToday) Box(Modifier.size(22.dp).clip(CircleShape).background(ui.accent))
                            Text(d.toString(), fontSize = 11.sp, color = if (isToday) Color.White else Color.Unspecified)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BatteryCard(ui: Ui, level: Int, modifier: Modifier) {
    Column(modifier.card(ui).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { level / 100f }, modifier = Modifier.size(84.dp), color = ui.accent,
                trackColor = LocalContentColor.current.copy(0.15f), strokeWidth = 8.dp
            )
            Text("$level%", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text("Battery", fontSize = 12.sp, color = LocalContentColor.current.copy(0.6f))
    }
}

@Composable
fun NotesCard(st: LauncherSettings, ui: Ui) {
    Column(Modifier.fillMaxWidth().card(ui).padding(14.dp)) {
        Text("Quick note", fontSize = 12.sp, color = ui.accent, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().heightIn(min = 70.dp)) {
            if (st.note.isEmpty()) {
                Text("Write something, or ask the AI to add a note…", color = LocalContentColor.current.copy(0.4f), fontSize = 14.sp)
            }
            BasicTextField(
                st.note, { st.note = it; st.save() },
                textStyle = TextStyle(color = LocalContentColor.current, fontSize = 14.sp, fontFamily = ui.look.font),
                cursorBrush = SolidColor(ui.accent), modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ---------------------------------------------------------------- DRAWER
@Composable
fun Drawer(st: LauncherSettings, ui: Ui, apps: List<AppItem>, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val gridState = rememberLazyGridState()
    var q by remember { mutableStateOf("") }
    val list = remember(apps, q) { if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), true) } }
    val letters = remember(list) { list.map { initial(it.label) }.distinct() }

    Box(Modifier.fillMaxSize().background(ui.look.drawerScrim).systemBarsPadding()) {
        Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 8.dp)) {
            OutlinedTextField(
                q, { q = it }, singleLine = true,
                placeholder = { Text("Search apps") },
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, end = 8.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let { onOpen(it.pkg) } })
            )
            LazyVerticalGrid(
                GridCells.Fixed(st.columns.coerceIn(3, 6)), state = gridState,
                modifier = Modifier.padding(end = 22.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                items(list, key = { it.pkg }) { app ->
                    var menu by remember { mutableStateOf(false) }
                    val pinned = app.pkg in st.dock
                    val onHome = app.pkg in st.home
                    Box(contentAlignment = Alignment.Center) {
                        AppTile(app, ui, { onOpen(app.pkg) }, { menu = true })
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text(if (onHome) "Remove from home" else "Add to home") }, onClick = {
                                Sfx.play(Sound.TAP); menu = false
                                st.home = if (onHome) st.home - app.pkg else st.home + app.pkg
                                st.save()
                            })
                            DropdownMenuItem(text = { Text(if (pinned) "Unpin from dock" else "Pin to dock") }, onClick = {
                                Sfx.play(Sound.TAP); menu = false
                                st.dock = if (pinned) st.dock - app.pkg else if (st.dock.size < 5) st.dock + app.pkg else st.dock
                                st.save()
                            })
                            DropdownMenuItem(text = { Text("App info") }, onClick = {
                                Sfx.play(Sound.TAP); menu = false
                                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            })
                            DropdownMenuItem(text = { Text("Uninstall") }, onClick = {
                                Sfx.play(Sound.TAP); menu = false
                                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            })
                        }
                    }
                }
            }
        }
        if (q.isBlank()) {
            Column(Modifier.align(Alignment.CenterEnd).padding(top = 60.dp)) {
                letters.forEach { c ->
                    Text(
                        c.toString(), fontSize = 10.sp, color = ui.accent,
                        modifier = Modifier.clickable {
                            Sfx.play(Sound.TICK)
                            scope.launch { gridState.scrollToItem(list.indexOfFirst { initial(it.label) == c }.coerceAtLeast(0)) }
                        }.padding(horizontal = 6.dp, vertical = 1.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EdgePanel(st: LauncherSettings, ui: Ui, apps: List<AppItem>, onOpen: (String) -> Unit, onClose: () -> Unit) {
    val list = (st.dock + st.home + st.recents).distinct().mapNotNull { p -> apps.find { it.pkg == p } }.take(8)
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(0.35f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
    ) {
        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 8.dp).card(ui).padding(12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (list.isEmpty()) Text("Pin apps or open a few to fill this panel", fontSize = 12.sp, modifier = Modifier.width(120.dp))
            list.forEach { a -> AppIcon(a, ui, Modifier.pressScale({ onOpen(a.pkg) })) }
        }
    }
}

// ---------------------------------------------------------------- SETTINGS
@Composable
fun Section(title: String, ui: Ui, content: @Composable ColumnScope.() -> Unit) {
    Text(title, color = ui.accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp, start = 4.dp))
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(if (ui.look.light) Color.Black.copy(0.05f) else Color.White.copy(0.07f)).padding(16.dp),
        content = content
    )
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, { Sfx.play(Sound.TOGGLE); onChange(it) })
    }
}

@Composable
fun PillChip(label: String, selected: Boolean, ui: Ui, dot: Color? = null, silent: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) ui.accent else LocalContentColor.current.copy(0.12f))
            .clickable { if (!silent) Sfx.play(Sound.TOGGLE); onClick() }.padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (dot != null) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(6.dp))
        }
        Text(label, fontSize = 13.sp, color = if (selected) Color.White else Color.Unspecified)
    }
}

@Composable
fun SettingsScreen(st: LauncherSettings, ui: Ui, apps: List<AppItem>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val battery = rememberBattery()
    val bg = if (ui.look.light) Color(0xF2F6F1E7) else Color(0xF2101018)
    var editing by remember { mutableStateOf<Widget?>(null) }
    var creating by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(bg).systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("✕", fontSize = 24.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
        }

        Section("Look", ui) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Look.values().forEach { l ->
                    val sel = l == st.look
                    val shape = RoundedCornerShape(20.dp)
                    Box(
                        Modifier.size(92.dp, 124.dp).clip(shape)
                            .background(Brush.linearGradient(listOf(ui.accent, Color(0xFF15152A))))
                            .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color.White.copy(0.2f), shape)
                            .clickable { Sfx.play(Sound.TOGGLE); st.look = l; st.save() }
                    ) {
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(l.top, l.bottom))))
                        Text(l.title, fontSize = 11.sp, color = l.text, textAlign = TextAlign.Center,
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.TopCenter).padding(8.dp))
                        Box(
                            Modifier.align(Alignment.BottomCenter).padding(8.dp).fillMaxWidth().height(28.dp)
                                .clip(RoundedCornerShape((l.radius / 2).dp))
                                .background(l.card.copy(alpha = if (l.glassy) 0.3f else l.card.alpha))
                        )
                    }
                }
            }
        }

        Section("Graphics", ui) {
            Text("Quality", fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Quality.values().forEach { q ->
                    PillChip(q.title, q == st.quality, ui) { st.quality = q; st.save() }
                }
            }
            Text(
                "Battery saver turns the animations off. Ultra adds denser stars, rain and particles.",
                fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 8.dp, bottom = 14.dp)
            )
            Text("Animated background", fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BackdropStyle.values().forEach { b ->
                    BackdropThumb(b, b == st.backdrop, ui) { st.backdrop = b; st.save() }
                }
            }
            Spacer(Modifier.height(10.dp))
            ToggleRow("Floating particles", st.particles) { st.particles = it; st.save() }
        }

        Section("Home layout", ui) {
            Text("Standard is the normal home screen. The others turn it into a sci-fi HUD with rings, gauges and your apps orbiting the core.",
                fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeStyle.values().forEach { h ->
                    HomeThumb(h, h == st.homeStyle, ui) { st.homeStyle = h; st.save() }
                }
            }
        }

        Section("Clock style", ui) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ClockStyle.values().forEach { s ->
                    PillChip(s.title, s == st.clock, ui) { st.clock = s; st.save() }
                }
            }
            Text("Used on the Standard home screen. HUD layouts have their own core clock.",
                fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 8.dp))
        }

        Section("Icon colours", ui) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconTint.values().forEach { s ->
                    PillChip(s.title, s == st.tint, ui) { st.tint = s; st.save() }
                }
            }
            Text("Auto = original colours on Standard, themed colours on HUD layouts. Mono is greyscale, Accent tints every icon with your accent, Rainbow gives each app its own colour.",
                fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(vertical = 8.dp))
            OutlinedTextField(
                st.tintHex, { st.tintHex = it; st.save() }, singleLine = true,
                label = { Text("Custom colour (#RRGGBB)") }, modifier = Modifier.fillMaxWidth()
            )
        }

        Section("Colours & icons", ui) {
            Text("Accent")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accents.forEachIndexed { i, c ->
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(c)
                            .border(3.dp, if (i == st.accent) Color.White else Color.Transparent, CircleShape)
                            .clickable { Sfx.play(Sound.TICK); st.accent = i; st.save() }
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Icon shape")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconShape.values().forEach { s ->
                    Box(
                        Modifier.size(46.dp).clip(s.shape)
                            .background(if (s == st.shape) ui.accent else LocalContentColor.current.copy(0.25f))
                            .clickable { Sfx.play(Sound.TICK); st.shape = s; st.save() }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Icon size: ${st.iconSize.roundToInt()}")
            Slider(st.iconSize, { Sfx.play(Sound.TICK); st.iconSize = it; st.save() }, valueRange = 44f..72f)
            Text("Glass opacity (glass looks)")
            Slider(st.glass, { Sfx.play(Sound.TICK); st.glass = it; st.save() }, valueRange = 0.05f..0.5f)
        }

        Section("HTML widgets", ui) {
            Text(
                "Build your own widgets with HTML, CSS and JavaScript. They appear on the left page, and on the home screen if you tick that. The AI can write them too: try “make a pulsing clock widget”.",
                fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp)
            )
            st.widgets.forEach { w ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(w.name, Modifier.weight(1f))
                    TextButton(onClick = { Sfx.play(Sound.TAP); editing = w }) { Text("Edit") }
                }
            }
            Text("Quick add", fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WIDGET_PRESETS.forEach { p ->
                    PillChip("＋ " + p.name, false, ui, silent = true) {
                        st.addWidget(p.name, p.html, p.height, false)
                        Sfx.play(Sound.SUCCESS)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { Sfx.play(Sound.TAP); creating = true }) { Text("＋ Add widget") }
        }

        Section("Sound effects", ui) {
            ToggleRow("Sound effects", st.sfx) { st.sfx = it; Sfx.enabled = it; st.save() }
            Spacer(Modifier.height(6.dp))
            Text("Volume: ${(st.sfxVol * 100).roundToInt()}%")
            Slider(st.sfxVol, { st.sfxVol = it; Sfx.volume = it; Sfx.play(Sound.TICK); st.save() }, valueRange = 0f..1f)
            Text("Tap to preview", fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(bottom = 6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Sound.values().forEach { snd -> PillChip(snd.label, false, ui, silent = true) { Sfx.play(snd) } }
            }
        }

        Section("Music bar", ui) {
            val access = hasNotificationAccess(ctx)
            Text(
                if (access) "Notification access is on. The bar at the top shows the song with album art and a progress fill. Tap it to open the full player with a seek bar and controls."
                else "To show the song that's playing, turn on notification access for Nice UI 10 and come back.",
                fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp)
            )
            if (!access) {
                Button(onClick = { Sfx.play(Sound.TAP);
                    try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                }) { Text("Open notification access") }
            }
        }

        Section("Layout", ui) {
            Text("Drawer columns: ${st.columns}")
            Slider(st.columns.toFloat(), { Sfx.play(Sound.TICK); st.columns = it.roundToInt(); st.save() }, valueRange = 3f..6f, steps = 2)
            Text("Home columns: ${st.homeCols}")
            Slider(st.homeCols.toFloat(), { Sfx.play(Sound.TICK); st.homeCols = it.roundToInt(); st.save() }, valueRange = 3f..5f, steps = 1)
            ToggleRow("Show app names", st.labels) { st.labels = it; st.save() }
            ToggleRow("Blur wallpaper behind panels", st.blur) { st.blur = it; st.save() }
        }

        Section("System", ui) {
            Button(onClick = { Sfx.play(Sound.TAP);
                try { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
            }) { Text("Set as default launcher") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { Sfx.play(Sound.TAP);
                try {
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { }
            }) { Text("Change wallpaper") }
        }

        Section("AI assistant (OpenAI)", ui) {
            Text(
                "Paste an API key from platform.openai.com. It is separate from a ChatGPT subscription and billed per use. The key is stored only on this phone.",
                fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp)
            )
            OutlinedTextField(
                st.apiKey, { st.apiKey = it; st.save() }, singleLine = true, label = { Text("API key") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                st.model, { st.model = it; st.save() }, singleLine = true,
                label = { Text("Model") }, modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(30.dp))
    }

    if (creating) {
        WidgetEditor(
            null, ui, apps, battery,
            onSave = { st.widgets = st.widgets + it; st.save(); creating = false },
            onDelete = null,
            onDismiss = { creating = false }
        )
    }
    editing?.let { cur ->
        WidgetEditor(
            cur, ui, apps, battery,
            onSave = { n -> st.widgets = st.widgets.map { if (it.id == n.id) n else it }; st.save(); editing = null },
            onDelete = { st.widgets = st.widgets.filter { it.id != cur.id }; st.save(); editing = null },
            onDismiss = { editing = null }
        )
    }
}

// ---------------------------------------------------------------- AI
class Msg(val fromUser: Boolean, val text: String)

@Composable
fun AiSheet(st: LauncherSettings, ui: Ui, onClose: () -> Unit, exec: (JSONObject) -> String?) {
    val msgs = remember {
        mutableStateListOf(Msg(false, "Hey! Tell me what to do: “open Spotify”, “set a 10 minute timer”, “make it neon”, “put Camera on my dock”…"))
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size, busy) { listState.animateScrollToItem(msgs.size) }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        input = ""
        msgs.add(Msg(true, text))
        if (st.apiKey.isBlank()) {
            Sfx.play(Sound.ERROR)
            msgs.add(Msg(false, "Add your OpenAI API key first: close this, long-press the home screen, open Settings → AI assistant."))
            return
        }
        busy = true
        Sfx.play(Sound.TAP)
        scope.launch {
            try {
                val hist = msgs.drop(1).takeLast(12).map { (if (it.fromUser) "user" else "assistant") to it.text }
                val r = Ai.ask(st.apiKey.trim(), st.model.trim(), hist)
                val notes = mutableListOf<String>()
                r.optJSONArray("actions")?.let { arr ->
                    for (i in 0 until arr.length()) exec(arr.getJSONObject(i))?.let { notes.add("⚠ $it") }
                }
                Sfx.play(if (notes.isEmpty()) Sound.SUCCESS else Sound.ERROR)
                msgs.add(Msg(false, (listOf(r.optString("say")) + notes).filter { it.isNotBlank() }.joinToString("\n")))
            } catch (e: Exception) {
                Sfx.play(Sound.ERROR)
                msgs.add(Msg(false, "⚠ ${e.message}"))
            }
            busy = false
        }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val t = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (t != null) { input = t; send() }
    }

    val bg = if (ui.look.light) Color(0xF2F6F1E7) else Color(0xF2090910)
    Column(Modifier.fillMaxSize().background(bg).systemBarsPadding().imePadding().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("✦ Assistant", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ui.accent, modifier = Modifier.weight(1f))
            Text("✕", fontSize = 24.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(msgs.size) { i ->
                val m = msgs[i]
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                    Text(
                        m.text,
                        Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (m.fromUser) ui.accent.copy(0.85f) else LocalContentColor.current.copy(0.10f))
                            .padding(12.dp),
                        color = if (m.fromUser) Color.White else Color.Unspecified
                    )
                }
            }
            if (busy) item { Text("…", modifier = Modifier.padding(8.dp)) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Tell me what to do") }, shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            Text("🎤", fontSize = 24.sp, modifier = Modifier.clickable {
                try {
                    speech.launch(
                        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    )
                } catch (e: Exception) { msgs.add(Msg(false, "⚠ Voice input isn't available on this phone.")) }
            }.padding(8.dp))
            Button(onClick = { Sfx.play(Sound.TAP); send() }, enabled = !busy) { Text("➤") }
        }
    }
}

package com.nice.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Empty on purpose: having it enabled in "Notification access" lets the launcher read the now-playing session. */
class MediaListener : NotificationListenerService()

data class MediaInfo(
    val title: String, val artist: String, val playing: Boolean,
    val art: ImageBitmap?, val tint: Color?, val pos: Long, val dur: Long, val pkg: String
)

private fun controllerOf(ctx: Context): MediaController? = try {
    val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    val all = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
    all.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: all.firstOrNull()
} catch (e: Exception) {
    null
}

// album art is decoded once per song, not on every refresh
private var artKey = ""
private var artBmp: ImageBitmap? = null
private var artTint: Color? = null

private fun updateArt(m: MediaMetadata, key: String) {
    if (key == artKey && artBmp != null) return
    artKey = key
    val bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
        ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
        ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
    if (bmp == null || bmp.isRecycled || bmp.width < 2 || bmp.height < 2) {
        artBmp = null
        artTint = null
        return
    }
    try {
        val side = minOf(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        artBmp = Bitmap.createScaledBitmap(square, 256, 256, true).asImageBitmap()
        val px = Bitmap.createScaledBitmap(square, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(px, hsv)
        hsv[1] = hsv[1].coerceIn(0.35f, 1f)
        hsv[2] = hsv[2].coerceIn(0.6f, 1f)
        artTint = Color(android.graphics.Color.HSVToColor(hsv))
    } catch (e: Exception) {
        artBmp = null
        artTint = null
    }
}

fun readMedia(ctx: Context): MediaInfo? {
    val c = controllerOf(ctx) ?: return null
    val m = c.metadata ?: return null
    val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
    val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
        ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
    updateArt(m, "$title|$artist")
    val ps = c.playbackState
    val playing = ps?.state == PlaybackState.STATE_PLAYING
    var pos = ps?.position ?: 0L
    if (ps != null && playing && ps.lastPositionUpdateTime > 0) {
        pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
    }
    val dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
    pos = if (dur > 0) pos.coerceIn(0L, dur) else pos.coerceAtLeast(0L)
    return MediaInfo(title, artist, playing, artBmp, artTint, pos, dur, c.packageName)
}

fun mediaCmd(ctx: Context, cmd: String) {
    val c = controllerOf(ctx) ?: return
    val t = c.transportControls
    when (cmd) {
        "prev" -> t.skipToPrevious()
        "next" -> t.skipToNext()
        else -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
    }
}

fun mediaSeek(ctx: Context, ms: Long) {
    controllerOf(ctx)?.transportControls?.seekTo(ms)
}

fun hasNotificationAccess(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: ""
    return s.contains(ctx.packageName)
}

@Composable
fun rememberMedia(): MediaInfo? {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf<MediaInfo?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            info = withContext(Dispatchers.Default) { readMedia(ctx) }
            delay(1000)
        }
    }
    return info
}

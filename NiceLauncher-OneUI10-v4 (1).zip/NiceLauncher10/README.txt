Nice UI 10 launcher v4
======================
v3: HUD layouts, music bar, clock styles, icon colours, HTML widgets.
v4 (this version):
 * Widgets fixed: real https base URL (localStorage + fetch work), DOM storage on, safe link handling,
   on-screen JS error line, crash recovery, timers paused when the launcher is hidden, WebView freed properly,
   home page now scrolls so widgets can never squash the app grid. New bridge: Nice.vibrate/toast/sound/openUrl.
   Widget editor has a live preview and presets; Settings > HTML widgets has one-tap "Quick add" widgets.
 * Music bar redesigned: album art, tinted from the cover, scrolling title, progress fill, full player with
   seek bar and drawn play/pause/next/prev buttons.
 * Settings > Graphics: quality (Battery saver / Balanced / High / Ultra), animated backgrounds
   (Blobs, Starfield, Waves, Cyber grid, Rain, Plain) with previews, floating particles toggle.
   Home layouts now have preview cards too. The AI assistant can change these (set_quality, set_backdrop, set_sound).
 * Sound effects for taps, long-press, opening/closing panels, launching apps, switches, sliders, music controls,
   AI replies and errors. Generated in code (no audio files). Settings > Sound effects: on/off, volume, preview.

Build: open the NiceLauncher10 folder in Android Studio and run (or ./gradlew assembleDebug).
